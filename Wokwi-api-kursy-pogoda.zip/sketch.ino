#include <WiFi.h>
#include <PubSubClient.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// =====================================================
// WIFI
// =====================================================

const char* ssid = "Wokwi-GUEST";
const char* password = "";

// =====================================================
// MQTT
// =====================================================

const char* mqtt_server = "broker.mqtt.cool";
const int mqtt_port = 1883;

const char* topicWaluty = "projekt-wsb-waluty";
const char* topicPogoda = "projekt-wsb-pogoda";

WiFiClient espClient;
PubSubClient mqttClient(espClient);

// =====================================================
// NBP
// =====================================================

const char* nbpURL =
  "http://api.nbp.pl/api/exchangerates/tables/A/?format=json";

// =====================================================
// OPEN-METEO - GDYNIA
// =====================================================

const char* weatherURL =
  "https://api.open-meteo.com/v1/forecast"
  "?latitude=54.5189"
  "&longitude=18.5305"
  "&current=temperature_2m,relative_humidity_2m,wind_speed_10m"
  "&wind_speed_unit=ms";

// =====================================================
// CZAS
// =====================================================

unsigned long lastUpdate = 0;
const unsigned long updateInterval = 5000;

// =====================================================
// WALUTY
// =====================================================

float EUR = 0;
float USD = 0;
float GBP = 0;
float CHF = 0;

// =====================================================
// WIFI
// =====================================================

void connectWiFi() {

  Serial.println();
  Serial.println("=== WIFI ===");

  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  Serial.print("Laczenie");

  while (WiFi.status() != WL_CONNECTED) {

    delay(500);
    Serial.print(".");
  }

  Serial.println();
  Serial.println("WIFI OK");

  Serial.print("IP: ");
  Serial.println(WiFi.localIP());
}

// =====================================================
// MQTT
// =====================================================

bool connectMQTT() {

  if (mqttClient.connected()) {
    return true;
  }

  Serial.println();
  Serial.println("=== MQTT ===");

  String clientID = "ESP32-WOKWI-";
  clientID += String(random(0xFFFF), HEX);

  Serial.print("Laczenie z brokerem: ");
  Serial.println(mqtt_server);

  if (mqttClient.connect(clientID.c_str())) {

    Serial.println("MQTT POLACZONE!");
    return true;

  } else {

    Serial.print("MQTT BLAD, state=");
    Serial.println(mqttClient.state());

    return false;
  }
}

// =====================================================
// POBIERANIE WALUT NBP
// =====================================================

bool getCurrencies() {

  Serial.println();
  Serial.println("Pobieranie kursow NBP...");

  HTTPClient http;

  http.setTimeout(8000);

  if (!http.begin(nbpURL)) {

    Serial.println("Nie mozna otworzyc NBP");
    return false;
  }

  int httpCode = http.GET();

  Serial.print("NBP HTTP: ");
  Serial.println(httpCode);

  if (httpCode != 200) {

    http.end();
    return false;
  }

  String payload = http.getString();

  http.end();

  DynamicJsonDocument doc(12000);

  DeserializationError error =
    deserializeJson(doc, payload);

  if (error) {

    Serial.print("Blad JSON NBP: ");
    Serial.println(error.f_str());

    return false;
  }

  JsonArray rates = doc[0]["rates"];

  for (JsonObject rate : rates) {

    const char* code =
      rate["code"];

    float value =
      rate["mid"];

    if (strcmp(code, "EUR") == 0) {
      EUR = value;
    }

    else if (strcmp(code, "USD") == 0) {
      USD = value;
    }

    else if (strcmp(code, "GBP") == 0) {
      GBP = value;
    }

    else if (strcmp(code, "CHF") == 0) {
      CHF = value;
    }
  }

  Serial.println("NBP OK");

  Serial.print("EUR: ");
  Serial.println(EUR, 4);

  Serial.print("USD: ");
  Serial.println(USD, 4);

  Serial.print("GBP: ");
  Serial.println(GBP, 4);

  Serial.print("CHF: ");
  Serial.println(CHF, 4);

  return true;
}

// =====================================================
// WYSYŁANIE WALUT MQTT
// =====================================================

void publishCurrencies() {

  if (!mqttClient.connected()) {

    Serial.println(
      "Brak MQTT - waluty nie zostaly wyslane"
    );

    return;
  }

  String message =
    "EUR: " + String(EUR, 4) +
    " PLN | USD: " + String(USD, 4) +
    " PLN | GBP: " + String(GBP, 4) +
    " PLN | CHF: " + String(CHF, 4) +
    " PLN";

  Serial.println();
  Serial.println("WYSYLAM WALUTY:");
  Serial.println(message);

  bool result =
    mqttClient.publish(
      topicWaluty,
      message.c_str()
    );

  if (result) {

    Serial.println(
      "WALUTY -> MQTT OK"
    );

  } else {

    Serial.println(
      "WALUTY -> MQTT BLAD"
    );
  }
}

// =====================================================
// POGODA OPEN-METEO
// =====================================================

bool getWeather() {

  Serial.println();
  Serial.println("Pobieranie pogody Gdynia...");

  HTTPClient http;

  http.setTimeout(10000);

  if (!http.begin(weatherURL)) {

    Serial.println(
      "Nie mozna otworzyc Open-Meteo"
    );

    return false;
  }

  int httpCode = http.GET();

  Serial.print("Open-Meteo HTTP: ");
  Serial.println(httpCode);

  if (httpCode != 200) {

    http.end();
    return false;
  }

  String payload = http.getString();

  http.end();

  DynamicJsonDocument doc(6000);

  DeserializationError error =
    deserializeJson(doc, payload);

  if (error) {

    Serial.print(
      "Blad JSON pogody: "
    );

    Serial.println(
      error.f_str()
    );

    return false;
  }

  float temperature =
    doc["current"]["temperature_2m"] | 0.0;

  float humidity =
    doc["current"]["relative_humidity_2m"] | 0.0;

  float wind =
    doc["current"]["wind_speed_10m"] | 0.0;

  Serial.println("POGODA GDYNIA:");

  Serial.print("Temperatura: ");
  Serial.print(temperature, 1);
  Serial.println(" C");

  Serial.print("Wilgotnosc: ");
  Serial.print(humidity, 0);
  Serial.println(" %");

  Serial.print("Wiatr: ");
  Serial.print(wind, 1);
  Serial.println(" m/s");

  // ===================================================
  // MQTT POGODA
  // ===================================================

  if (!mqttClient.connected()) {

    Serial.println(
      "Brak MQTT - pogoda nie zostala wyslana"
    );

    return false;
  }

  String message =
    "GDYNIA | Temp: " +
    String(temperature, 1) +
    " C | Wilg: " +
    String(humidity, 0) +
    " % | Wiatr: " +
    String(wind, 1) +
    " m/s";

  Serial.println();
  Serial.println("WYSYLAM POGODE:");
  Serial.println(message);

  bool result =
    mqttClient.publish(
      topicPogoda,
      message.c_str()
    );

  if (result) {

    Serial.println(
      "POGODA -> MQTT OK"
    );

  } else {

    Serial.println(
      "POGODA -> MQTT BLAD"
    );
  }

  return true;
}

// =====================================================
// SETUP
// =====================================================

void setup() {

  Serial.begin(115200);

  delay(1000);

  Serial.println();
  Serial.println("==============================");
  Serial.println("ESP32 - MQTT");
  Serial.println("WALUTY + POGODA");
  Serial.println("==============================");

  // WiFi
  connectWiFi();

  // MQTT
  mqttClient.setServer(
    mqtt_server,
    mqtt_port
  );

  // Pierwsze polaczenie
  connectMQTT();

  // Pierwsze dane
  if (mqttClient.connected()) {

    if (getCurrencies()) {
      publishCurrencies();
    }

    getWeather();
  }

  lastUpdate = millis();
}

// =====================================================
// LOOP
// =====================================================

void loop() {

  // -----------------------------------------------
  // WIFI
  // -----------------------------------------------

  if (
    WiFi.status() != WL_CONNECTED
  ) {

    connectWiFi();
  }

  // -----------------------------------------------
  // MQTT
  // -----------------------------------------------

  if (
    !mqttClient.connected()
  ) {

    connectMQTT();
  }

  mqttClient.loop();

  // -----------------------------------------------
  // AKTUALIZACJA CO 5 SEKUND
  // -----------------------------------------------

  if (
    millis() - lastUpdate >=
    updateInterval
  ) {

    lastUpdate = millis();

    Serial.println();
    Serial.println("==============================");
    Serial.println("AKTUALIZACJA");
    Serial.println("==============================");

    if (
      mqttClient.connected()
    ) {

      // WALUTY
      if (getCurrencies()) {
        publishCurrencies();
      }

      // POGODA
      getWeather();

    } else {

      Serial.println(
        "MQTT niedostepne - brak wysylania"
      );
    }
  }

  delay(10);
}
