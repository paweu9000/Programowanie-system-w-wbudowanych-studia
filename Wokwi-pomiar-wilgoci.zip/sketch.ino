#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>

const char* ssid = "Wokwi-GUEST";
const char* password = "";

const char* mqtt_server = "broker.mqtt.cool";
const int mqtt_port = 1883;
const char* mqtt_topic = "projekt-wsb-gdynia";

WiFiClient espClient;
PubSubClient client(espClient);

#define DHTPIN 5
#define DHTTYPE DHT22

DHT dht(DHTPIN, DHTTYPE);
LiquidCrystal_I2C lcd(0x27, 16, 4);

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Łączenie z WiFi: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi połączone!");
  Serial.print("Adres IP: ");
  Serial.println(WiFi.localIP());
}

void reconnect() {

  while (!client.connected()) {
    Serial.print("Próba połączenia z MQTT...");

    String clientId = "ESP32Client-WSB-";
    clientId += String(random(0xffff), HEX);
    
    if (client.connect(clientId.c_str())) {
      Serial.println("Połączono z brokerem MQTT!");
    } else {
      Serial.print("Błąd, rc=");
      Serial.print(client.state());
      Serial.println(" Spróbuję ponownie za 5 sekund");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  dht.begin();

  lcd.init();
  lcd.backlight();
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Inicjalizacja...");

  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Odczytywanie temp.");
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("Nie udało się odczytać danych z czujnika DHT!");
    return;
  }

  Serial.print("Temperatura: ");
  Serial.print(temp);
  Serial.print(" °C  ");
  Serial.print("Wilgotność: ");
  Serial.print(hum);
  Serial.println(" %");

  String payload = "Temp: " + String(temp) + " C, Wilg: " + String(hum) + " %";
  client.publish(mqtt_topic, payload.c_str());
  Serial.println("Wysłano na MQTT: " + payload);

  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Temp.: ");
  lcd.print(temp);
  lcd.print(" C");
  
  lcd.setCursor(0, 1);
  lcd.print("Wilg.: ");
  lcd.print(hum);
  lcd.print(" %");

  delay(5000);
}